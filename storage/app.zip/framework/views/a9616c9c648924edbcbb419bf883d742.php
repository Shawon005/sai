
  <?php $__env->startSection('content'); ?> 
      
      <!-- Page Header-->
      <!-- Swiper-->
    
      <?php $setting=setting(); ?>
      <section class="section section-sm bg-gray-100">
        <div class="container">
          <div class="row row-30">
            <div class="col-lg-12">
              
              <!-- Post Miranda-->
              <article class="post-miranda">
                <!-- <div class="post-miranda-content"> -->
                  <img src="<?php echo e($setting->sub_bannar); ?>" alt="" width="1170" height="397"/>
                <!-- </div> -->
                
              </article>

            </div>
            
          </div>
        </div>
      </section>
      <?php echo $__env->make('frontend.layout.partial.page-banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <section class="section section-sm bg-gray-100">
        <div class="container">

          <div class="row row-50">
            <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
              <article class="post-corporate news-image">    
                <a class="post-corporate-figure" href="<?php echo e(route('home.newses',$news->news_slug)); ?>"><img src="<?php echo e($news->news_image); ?>" alt="" width="768" height="414"/>
                </a>
                <div class="post-corporate-content">
                  <div class="post-corporate-header">
                    <!-- Badge-->
                    <div class="badge badge-primary"><?php echo e($news->news_category); ?>

                    </div>
                    <time class="post-corporate-time" datetime="2022"><?php echo e(dateFormatconverter($news->news_cdt)); ?></time>
                    <div class="post-corporate-view">
                      <span><?php echo e(user($news->user_id)); ?></span>
                    </div>
                  </div>
                  <h4 class="post-corporate-title">
                    <a href="<?php echo e(route('home.newses',$news->news_slug)); ?>"><?php echo e($news->news_title); ?></a>
                  </h4>
                  <div class="post-corporate-text">
                    <p><?php echo $news->news_description; ?></p>
                  </div>
                </div>
              </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          </div>

         
        </div>
      </section>
      
      


      <!-- Page Footer-->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/frontend/news.blade.php ENDPATH**/ ?>