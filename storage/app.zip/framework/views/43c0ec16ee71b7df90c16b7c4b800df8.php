<?php $setting=setting(); ?>
      <section class="section section-sm bg-gray-100">
        <div class="container">
          <div class="row row-50">
            <div class="col-lg-12">
              <article class="banner banner-lg context-dark">
                <div class="banner-inner">
                  <div class="banner-image"><img src="<?php echo e($setting->page_banner); ?>" alt="" width="1170" height="397"/>
                  </div>
                  <div class="banner-body">
                    <div class="banner-content">
                      <h2 class="banner-title"><a href="#"> $100 bonus for new customers only</a></h2><a class="button button-gray-outline" href="#"> Sign up today</a>
                    </div>
                  </div>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/frontend/layout/partial/page-banner.blade.php ENDPATH**/ ?>