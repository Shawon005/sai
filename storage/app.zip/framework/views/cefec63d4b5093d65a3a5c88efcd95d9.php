
  <?php $__env->startSection('content'); ?>
      <!-- Page Header-->
   

      <!-- Section Breadcrumbs-->
      <section class="section parallax-container breadcrumbs-wrap" data-parallax-img="<?php echo e(asset('')); ?>frontend/images/bg-breadcrumbs-1-1920x726.jpg">
        <div class="parallax-content breadcrumbs-custom context-dark">
          <div class="container">
            <h3 class="breadcrumbs-custom-title">News post</h3>
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.html">Home</a></li>
              <li><a href="#">Pages</a></li>
              <li class="active">News post</li>
            </ul>
          </div>
        </div>
      </section>

      <!-- Blog Post-->
      <section class="section section-sm bg-gray-100">
        <div class="container">
          <div class="row row-30">
            <div class="col-lg-8">
              <div class="blog-post">
                <!-- Badge-->
                <div class="badge badge-secondary">News
                </div>
                <h3 class="blog-post-title"><?php echo e($news->news_title); ?></h3>
                <div class="blog-post-header">
                  <div class="blog-post-author"><img class="img-circle" src="images/user-3-63x63.jpg" alt="" width="63" height="63"/>
                    <p class="post-author"><?php echo e(user($news->user_id)); ?></p>
                  </div>
                  <div class="blog-post-meta">
                    <time class="blog-post-time" datetime="2022"><span class="icon mdi mdi-clock"></span><?php echo e(dateFormatconverter($news->news_cdt)); ?></time>
                    <div class="blog-post-comment"><span class="icon mdi mdi-comment-outline"></span>345</div>
                    <div class="blog-post-view"><span class="icon fl-justicons-visible6"></span>234</div>
                  </div>
                </div>
                <div class="blog-post-author-quote">
                  <p></p>
                </div>
                
                <div class="blog-post-content">
                <!-- <p><?php echo $news->news_description; ?></p> -->
                 <img src="<?php echo e($news->news_image); ?>" alt="" width="683" height="407"/>
                 
                  <!-- Quote Default-->
                  <article class="quote-default">
                    <div class="quote-default-text">
                      <p class="q">This week in sports betting proved to be very unpredictable</p>
                    </div>
                  </article>
                  <p><?php echo $news->news_description; ?></p>
                </div>
              </div>
            
              
            </div>
            <div class="col-lg-4">
              <!-- Blog Alide-->
              <div class="block-aside">
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  <article class="heading-component">
                    <div class="heading-component-inner">
                      <h5 class="heading-component-title">Categories
                      </h5>
                    </div>
                  </article>

                  <!--Block Categories-->
                  <div class="block-categories">
                    <ul class="list-marked list-marked-categories">
                    <li><a href="<?php echo e(route('home.news_cat','Kronika')); ?>">Kronika</a><span class="list-marked-counter">68</span></li>
                      <li><a href="<?php echo e(route('home.news_cat','Artikel')); ?>">Artikel</a><span class="list-marked-counter">16</span></li>
                      <li><a href="<?php echo e(route('home.news_cat','Sport')); ?>">Sport</a><span class="list-marked-counter">20</span></li>
                      <li><a href="<?php echo e(route('home.news_cat','Spel')); ?>">Spel</a><span class="list-marked-counter">20</span></li>
                    </ul>
                  </div>
                </div>
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  <article class="heading-component">
                    <div class="heading-component-inner">
                      <h5 class="heading-component-title">In The Spotlight
                      </h5><a class="button button-xs button-gray-outline" href="news.html">All News</a>
                    </div>
                  </article>

                  <!-- List Post Classic-->
                  <div class="list-post-classic">
                      <!-- Post Classic-->
                      <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <article class="post-classic">
                        <div class="post-classic-aside"><a class="post-classic-figure" href="<?php echo e(route('home.news',$news->news_slug)); ?>"><img src="<?php echo e($news->news_image); ?>" alt="" width="94" height="94"/></a></div>
                        <div class="post-classic-main">
                          <p class="post-classic-title"><a href="<?php echo e(route('home.news',$news->news_slug)); ?>"><?php echo e($news->news_title); ?></a></p>
                          <div class="post-classic-time"><span class="icon mdi mdi-clock"></span>
                            <time datetime="2022"><?php echo e(dateFormatconverter($news->news_cdt)); ?></time>
                          </div>
                        </div>
                      </article>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <!-- Post Classic-->
                      
                      <!-- Post Classic-->
                     
                      <!-- Post Classic-->
                      
                  </div>
                </div>
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  

                  <!-- Buttons Media-->
               
                <div class="block-aside-item">
                  <!-- Heading Component-->
                 

                  <!-- Mail Form Modern-->
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/frontend/news-post.blade.php ENDPATH**/ ?>