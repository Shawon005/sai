
  <?php $__env->startSection('content'); ?> 
      
      <!-- Page Header-->
      <!-- Swiper-->
    
      <?php $setting=setting(); ?>
      <section class="section section-sm bg-gray-100">
        <div class="container">
          <div class="row row-30">
            <div class="col-lg-12">
              
              <!-- Post Miranda-->
              <article class="post-miranda">
                <!-- <div class="post-miranda-content"> -->
                  <img src="<?php echo e($setting->sub_bannar); ?>" alt="" width="1170" height="397"/>
                <!-- </div> -->
                
              </article>

            </div>
            
          </div>
        </div>
      </section>
      <?php echo $__env->make('frontend.layout.partial.page-banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <section class="section section-sm bg-gray-100">
        <div class="container">
          <div class="row row-30">
            <div class="col-lg-8">   
                <!-- Heading Component-->
                <!-- <article class="heading-component">
                  <div class="heading-component-inner">
                    <h5 class="heading-component-title">In The Spotlight
                    </h5>
                  </div>
                </article> -->
                <!-- Post Miranda-->
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <article class="post-miranda">
                  <div class="post-miranda-content">
                    <div class="post-miranda-main">
                      <div class="post-miranda-header">
                        <!-- Badge-->
                        <div class="badge badge-secondary"><?php echo e($blog->blog_category); ?>

                        </div>
                        <time class="post-miranda-time" datetime="2022"><?php echo e(dateFormatconverter($blog->blog_cdt)); ?>

                        </time>
                        <div class="post-miranda-view"><span class=""><?php echo e(user($blog->user_id)); ?></span>
                        </div>
                      </div>
                      <h4 class="post-miranda-title"><a href="<?php echo e(route('home.blog',$blog->blog_slug)); ?>"><?php echo e($blog->blog_name); ?></a></h4>
                      <div class="post-miranda-text">
                        <p><?php echo $blog->blog_description; ?></p>
                      </div>
                    </div>
                    <div class="post-miranda-aside"><a class="post-miranda-figure" href="<?php echo e(route('home.blog',$blog->blog_slug)); ?>"><img src="<?php echo e($blog->blog_image); ?>" alt="" width="207" height="152"/></a></div>
                  </div>
                  <div class="post-miranda-footer">
                    <div class="post-miranda-comment"><span class="icon mdi mdi-comment-outline"></span><a href="#">345 Comments</a></div>
                    <div class="post-miranda-share">
                      <ul class="group">
                        <li>Share</li>
                        <li><a class="icon fa-facebook" href="#"></a></li>
                        <li><a class="icon fa-twitter" href="#"></a></li>
                        <li><a class="icon fa-google-plus" href="#"></a></li>
                        <li><a class="icon fa-instagram" href="#"></a></li>
                      </ul>
                    </div>
                  </div>
                </article>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-4">
              <!-- Blog Alide-->
              <div class="block-aside">
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  <article class="heading-component">
                    <div class="heading-component-inner">
                      <h5 class="heading-component-title">Categories
                      </h5>
                    </div>
                  </article>

                  <!--Block Categories-->
                  <div class="block-categories">
                    <ul class="list-marked list-marked-categories">
                      <li><a href="<?php echo e(route('home.blog_cat','Kronika')); ?>">Kronika</a><span class="list-marked-counter">68</span></li>
                      <li><a href="<?php echo e(route('home.blog_cat','Artikel')); ?>">Artikel</a><span class="list-marked-counter">16</span></li>
                      <li><a href="<?php echo e(route('home.blog_cat','Sport')); ?>">Sport</a><span class="list-marked-counter">20</span></li>
                      <li><a href="<?php echo e(route('home.blog_cat','Spel')); ?>">Spel</a><span class="list-marked-counter">20</span></li>
                    </ul>
                  </div>
                </div>
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  <!-- <article class="heading-component">
                    <div class="heading-component-inner">
                      <h5 class="heading-component-title">In The Spotlight
                      </h5><a class="button button-xs button-gray-outline" href="news.html">All News</a>
                    </div>
                  </article> -->

                  <!-- List Post Classic-->
                  <div class="list-post-classic">
                      <!-- Post Classic-->
                      
                      <!-- Post Classic-->
                      
                      <!-- Post Classic-->
                    
                      <!-- Post Classic-->
                      
                  </div>
                </div>
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  

                  <!-- Buttons Media-->
              
                <div class="block-aside-item">
                  <!-- Heading Component-->
                

                  <!-- Mail Form Modern-->
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      


      <!-- Page Footer-->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/frontend/blog.blade.php ENDPATH**/ ?>