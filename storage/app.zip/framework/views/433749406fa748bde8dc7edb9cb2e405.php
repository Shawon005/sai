
  <?php $__env->startSection('content'); ?>
      <!-- Page Header-->
   

      <!-- Section Breadcrumbs-->
      <section class="section parallax-container breadcrumbs-wrap" data-parallax-img="<?php echo e(asset('')); ?>frontend/images/bg-breadcrumbs-1-1920x726.jpg">
        <div class="parallax-content breadcrumbs-custom context-dark">
          <div class="container">
            <h3 class="breadcrumbs-custom-title">Blog post</h3>
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.html">Home</a></li>
              <li><a href="#">Pages</a></li>
              <li class="active">Blog post</li>
            </ul>
          </div>
        </div>
      </section>

      <!-- Blog Post-->
      <section class="section section-sm bg-gray-100">
        <div class="container">
          <div class="row row-30">
            <div class="col-lg-8">
              <div class="blog-post">
                <!-- Badge-->
                <div class="badge badge-secondary">Blog
                </div>
                <h3 class="blog-post-title"><?php echo e($blog->blog_name); ?></h3>
                <div class="blog-post-header">
                  <div class="blog-post-author"><img class="img-circle" src="images/user-3-63x63.jpg" alt="" width="63" height="63"/>
                    <p class="post-author"><?php echo e(user($blog->user_id)); ?></p>
                  </div>
                  <div class="blog-post-meta">
                    <time class="blog-post-time" datetime="2022"><span class="icon mdi mdi-clock"></span><?php echo e(dateFormatconverter($blog->blog_cdt)); ?></time>
                    <div class="blog-post-comment"><span class="icon mdi mdi-comment-outline"></span>345</div>
                    <div class="blog-post-view"><span class="icon fl-justicons-visible6"></span>234</div>
                  </div>
                </div>
                <div class="blog-post-author-quote">
                  <p>.</p>
                </div>
                
                <div class="blog-post-content">
                <!-- <p><?php echo $blog->blog_description; ?></p> -->
                 <img src="<?php echo e($blog->blog_image); ?>" alt="" width="683" height="407"/>
                 
                  <!-- Quote Default-->
                  <article class="quote-default">
                    <div class="quote-default-text">
                      <p class="q">This week in sports betting proved to be very unpredictable</p>
                    </div>
                  </article>
                  <p><?php echo $blog->blog_description; ?></p>
                </div>
              </div>
            
              <div class="row">
                <div class="col-sm-12">
                  <!-- Heading Component-->
                  <article class="heading-component">
                    <div class="heading-component-inner">
                      <h5 class="heading-component-title">3 comments
                      </h5>
                    </div>
                  </article>

                  <div class="blog-post-comments">
                    <!-- Post Comment-->
                    <div class="post-comment post-comment-parent">
                      <div class="post-comment-aside"><img class="img-circle" src="images/user-4-69x69.jpg" alt="" width="69" height="69"/>
                      </div>
                      <div class="post-comment-main">
                        <div class="post-comment-header">
                          <h5 class="author-name">Linda Peterson</h5>
                          <time class="post-comment-time" datetime="2022">2 days ago
                          </time>
                        </div>
                        <div class="post-comment-text">
                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nu.</p>
                        </div>
                        <div class="post-comment-footer">
                          <div class="comment-like"><span class="icon mdi mdi-thumb-up-outline"></span><a href="#">32</a></div>
                          <div class="comment-reply"><span class="icon mdi mdi-comment-outline"></span><a href="#">Reply</a></div>
                        </div>
                      </div>
                    </div>
                    <!-- Post Comment-->
                    <div class="post-comment post-comment-child">
                      <div class="post-comment-aside"><img class="img-circle" src="images/user-5-69x69.jpg" alt="" width="69" height="69"/>
                      </div>
                      <div class="post-comment-main">
                        <div class="post-comment-header">
                          <h5 class="author-name">Erika Wood</h5>
                          <time class="post-comment-time" datetime="2022">2 days ago
                          </time>
                        </div>
                        <div class="post-comment-text">
                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam f.</p>
                        </div>
                        <div class="post-comment-footer">
                          <div class="comment-like"><span class="icon mdi mdi-thumb-up-outline"></span><a href="#">32</a></div>
                          <div class="comment-reply"><span class="icon mdi mdi-comment-outline"></span><a href="#">Reply</a></div>
                        </div>
                      </div>
                    </div>
                    <!-- Post Comment-->
                    <div class="post-comment">
                      <div class="post-comment-aside"><img class="img-circle" src="images/user-6-69x69.jpg" alt="" width="69" height="69"/>
                      </div>
                      <div class="post-comment-main">
                        <div class="post-comment-header">
                          <h5 class="author-name">Sam McMillan</h5>
                          <time class="post-comment-time" datetime="2022">2 days ago
                          </time>
                        </div>
                        <div class="post-comment-text">
                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Null.</p>
                        </div>
                        <div class="post-comment-footer">
                          <div class="comment-like"><span class="icon mdi mdi-thumb-up-outline"></span><a href="#">32</a></div>
                          <div class="comment-reply"><span class="icon mdi mdi-comment-outline"></span><a href="#">Reply</a></div>
                        </div>
                      </div>
                    </div>
                    <div class="comment-box">
                      <div class="comment-box-aside"><img class="img-circle" src="images/user-7-69x69.jpg" alt="" width="69" height="69"/>
                      </div>
                      <div class="comment-box-main">
                        <h5 class="comment-box-name">Miranda</h5>
                        <!-- RD Mailform-->
                        <form class="rd-mailform comment-box-form" id="comment_from"   method="post" action="<?php echo e(route('admin.review.store')); ?>">
                          <div class="form-wrap">
                            <label class="form-label" for="comment-message">Your comment</label>
                            <textarea class="form-input" id="comment-message" name="question" ></textarea>
                          </div>
                          <div class="form-button">
                            <button class="button button-primary" id="comment_box" type="submit">Submit</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <!-- Blog Alide-->
              <div class="block-aside">
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  <article class="heading-component">
                    <div class="heading-component-inner">
                      <h5 class="heading-component-title">Categories
                      </h5>
                    </div>
                  </article>

                  <!--Block Categories-->
                  <div class="block-categories">
                    <ul class="list-marked list-marked-categories">
                    <li><a href="<?php echo e(route('home.blog_cat','Kronika')); ?>">Kronika</a><span class="list-marked-counter">68</span></li>
                      <li><a href="<?php echo e(route('home.blog_cat','Artikel')); ?>">Artikel</a><span class="list-marked-counter">16</span></li>
                      <li><a href="<?php echo e(route('home.blog_cat','Sport')); ?>">Sport</a><span class="list-marked-counter">20</span></li>
                      <li><a href="<?php echo e(route('home.blog_cat','Spel')); ?>">Spel</a><span class="list-marked-counter">20</span></li>
                    </ul>
                  </div>
                </div>
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  <article class="heading-component">
                    <div class="heading-component-inner">
                      <h5 class="heading-component-title">In The Spotlight
                      </h5><a class="button button-xs button-gray-outline" href="news.html">All News</a>
                    </div>
                  </article>

                  <!-- List Post Classic-->
                  <div class="list-post-classic">
                      <!-- Post Classic-->
                      <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <article class="post-classic">
                        <div class="post-classic-aside"><a class="post-classic-figure" href="<?php echo e(route('home.blog',$blog->blog_slug)); ?>"><img src="<?php echo e($blog->blog_image); ?>" alt="" width="94" height="94"/></a></div>
                        <div class="post-classic-main">
                          <p class="post-classic-title"><a href="<?php echo e(route('home.blog',$blog->blog_slug)); ?>"><?php echo e($blog->blog_name); ?></a></p>
                          <div class="post-classic-time"><span class="icon mdi mdi-clock"></span>
                            <time datetime="2022"><?php echo e(dateFormatconverter($blog->blog_cdt)); ?></time>
                          </div>
                        </div>
                      </article>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <!-- Post Classic-->
                      
                      <!-- Post Classic-->
                     
                      <!-- Post Classic-->
                      
                  </div>
                </div>
                <div class="block-aside-item">
                  <!-- Heading Component-->
                  

                  <!-- Buttons Media-->
               
                <div class="block-aside-item">
                  <!-- Heading Component-->
                 

                  <!-- Mail Form Modern-->
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  $(document).ready(function() {
  $('#comment_box').on('click',function(){
    alert('click');
  });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/frontend/blog-post.blade.php ENDPATH**/ ?>