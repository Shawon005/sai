

  <?php $__env->startSection('content'); ?>   
      <!-- Page Header-->
  

      <!-- Swiper-->
      <!-- <section class="section swiper-container swiper-slider swiper-classic bg-gray-2" data-loop="true" data-autoplay="4000" data-simulate-touch="false" data-slide-effect="fade">
        <div class="swiper-wrapper">
          <div class="swiper-slide" data-slide-bg="images/slider-1-slide-1-1920x671.jpg">
            <div class="container">
              <div class="swiper-slide-caption">
                <h1 data-caption-animate="fadeInUp" data-caption-delay="100">Safe <br> Betting</h1>
                <h4 data-caption-animate="fadeInUp" data-caption-delay="200">With 100% Risk-Free Guarantee</h4><a class="button button-gray-outline" data-caption-animate="fadeInUp" data-caption-delay="300" href="#">Get started</a>
              </div>
            </div>
          </div>
          <div class="swiper-slide" data-slide-bg="images/slider-1-slide-2-1920x671.jpg">
            <div class="container">
              <div class="swiper-slide-caption">
                <h1 data-caption-animate="fadeInUp" data-caption-delay="100">Easy Bets</h1>
                <h4 data-caption-animate="fadeInUp" data-caption-delay="200">With the lowest commissions</h4><a class="button button-gray-outline" data-caption-animate="fadeInUp" data-caption-delay="300" href="#">Join Us</a>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-button swiper-button-prev"></div>
        <div class="swiper-button swiper-button-next"></div>
        <div class="swiper-pagination"></div>
      </section> -->

    

      <?php echo $__env->make('frontend.layout.partial.page-banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php $setting=setting(); ?>
      <section class="section section-sm bg-gray-100">
        <div class="container">
          <div class="row row-50">
            <div class="col-lg-12">
              
              <!-- Post Miranda-->
              <article class="post-miranda">
                <!-- <div class="post-miranda-content"> -->
                  <img src="<?php echo e(asset('')); ?>frontend/images/gallery-soccer-3-original.jpg" alt="" width="1170" height="397"/>
                <!-- </div> -->
              </article>
            </div>
            
          </div>
        </div>
      </section>
      <section class="section section-sm bg-gray-100">
        <div class="container">
          <div class="row row-50">
            <div class="col-lg-12">
              
              <!-- Post Miranda-->
              <article class="">
                <!-- <div class="post-miranda-content"> -->
                  <div>
                    <p><?php echo e($setting->page_contain1); ?>

                    </p>
                  </div>
                  <div class="down-logo" >
                    <img src="<?php echo e($setting->header_logo); ?>" alt="" width="280" height="100" style="background-color:black"/>
                  </div>
                  <p><?php echo e($setting->page_contain2); ?>

                    </p>
                  </div>
                <!-- </div> -->
              </article>
            </div>
          </div>
        </div>
      </section>
      
      



      

      <!-- Page Footer-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/frontend/contact.blade.php ENDPATH**/ ?>