<aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="user-profile"> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><img src="<?php echo e(asset('')); ?>assets/images/users/user-demo.png" alt="user" /><span class="hide-menu">Steave Jobs </span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="javascript:void()">My Profile </a></li>
                                <li><a href="javascript:void()">Change Password</a></li>
                                <li><a href="<?php echo e(route('admin.logout')); ?>">Logout</a></li>
                            </ul>
                        </li>
                        <li class="nav-devider"></li>
                        <li class="nav-small-cap">CMS</li>
                        <li> <a class=" waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-gauge"></i><span class="hide-menu">Dashboard</span></a> 
                        <!-- <span class="label label-rouded label-themecolor pull-right">4</span> -->
                           
                        </li>
                        <li> <a class="waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-bullseye"></i><span class="hide-menu">Homepage</span></a>
                           
                        </li>
                        <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-email"></i><span class="hide-menu">Page</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="#">Tabl책</a></li>
                                <li><a href="<?php echo e(route('admin.blog.index')); ?>">Poddar & Magasin</a></li>
                                <li><a href="<?php echo e(route('admin.news.index')); ?>">Nyheter</a></li>
                                <li><a href="<?php echo e(route('admin.faq.index')); ?>">Spelansvar</a></li>
                                <li><a href="<?php echo e(route('admin.user.index')); ?>">Andelar </a></li>
                                <li><a href="<?php echo e(route('admin.activices.index')); ?>">Aktiviteter</a></li>
                                <li><a href="<?php echo e(route('admin.slider.index')); ?>">Speltips </a></li>
                                <li><a href="<?php echo e(route('admin.setting.index')); ?>">Poolspel</a></li>
                                <li><a href="<?php echo e(route('admin.link.index')); ?>">Reducera</a></li>
                                <li><a href="<?php echo e(route('admin.client.index')); ?>">Speltruppen</a></li>
                            </ul>
                        </li>
                        <li> <a class=" waves-effect waves-dark" href="<?php echo e(route('admin.news.index')); ?>" aria-expanded="false"><i class="mdi mdi-chart-bubble"></i><span class="hide-menu">News</a>
                           
                          
                        </li>
                        
                        <li> <a class=" waves-effect waves-dark" href="<?php echo e(route('admin.review.index')); ?>" aria-expanded="false"><i class="mdi mdi-file"></i><span class="hide-menu">Reducera</span></a>
                           
                           
                        </li>
                        <li> <a class=" waves-effect waves-dark" href="<?php echo e(route('admin.setting.index')); ?>" aria-expanded="false"><i class="mdi mdi-table"></i><span class="hide-menu">Settings </span></a>
                           
                        </li>
                        <li> <a class=" waves-effect waves-dark" href="<?php echo e(route('admin.logout')); ?>" aria-expanded="false"><i class="mdi mdi-widgets"></i><span class="hide-menu">Logout</span></a>
                           
                        </li>   
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/Admin/partial/slider.blade.php ENDPATH**/ ?>