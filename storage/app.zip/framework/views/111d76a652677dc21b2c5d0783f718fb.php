<?php $setting=setting(); ?>
<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <!-- Site Title-->
    <title>SAI::Home</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="<?php echo e(asset('')); ?>frontend/images/favicon.ico" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>frontend///fonts.googleapis.com/css?family=Kanit:300,400,500,500i,600%7CRoboto:400,900">
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>frontend/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>frontend/css/fonts.css">
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>frontend/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>frontend/css/custom.css">
  </head>
  <body>
    <div class="preloader">
      <div class="preloader-body">
        <div class="preloader-item"></div>
      </div>
    </div>
   
    <div class="page">
       
        <?php echo $__env->make('frontend.layout.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>  
        <?php echo $__env->make('frontend.layout.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="snackbars" id="form-output-global"></div>
    
    <!-- Javascript-->
    <script src="<?php echo e(asset('')); ?>frontend/js/core.min.js"></script>
    <script src="<?php echo e(asset('')); ?>frontend/js/script.js"></script>
  </body>
</html><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/frontend/layout/master.blade.php ENDPATH**/ ?>