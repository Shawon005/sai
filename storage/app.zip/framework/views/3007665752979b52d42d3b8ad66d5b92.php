
     <footer class="section footer-classic footer-classic-dark">
        <div class="footer-classic-main">
          <div class="container">
            <div class="row row-100 ">
              <div class="col-lg-3">
                <p class="heading-7">Studio All In</p>
                <ul class="list-unstyled">
                  <li><a href="<?php echo e($setting->pt1_option1_link); ?>"><?php echo e($setting->pt1_option1_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt1_option2_link); ?>"><?php echo e($setting->pt1_option2_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt1_option3_link); ?>"><?php echo e($setting->pt1_option3_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt1_option4_link); ?>"><?php echo e($setting->pt1_option4_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt1_option5_link); ?>"><?php echo e($setting->pt1_option5_text); ?></a></li>
                </ul>
              </div>
              <div class="col-lg-3">
                <p class="heading-7">Spel</p>
                <ul class="list-unstyled">
                  <li><a href="<?php echo e($setting->pt2_option1_link); ?>"><?php echo e($setting->pt2_option1_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt2_option2_link); ?>"><?php echo e($setting->pt2_option2_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt2_option3_link); ?>"><?php echo e($setting->pt2_option3_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt2_option4_link); ?>"><?php echo e($setting->pt2_option4_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt2_option5_link); ?>"><?php echo e($setting->pt2_option5_text); ?></a></li>
                </ul>
              </div>
              <div class="col-lg-3">
                <p class="heading-7">Social Medier</p>
                <ul class="list-unstyled">
                  <li><a class="icon icon-corporate fa fa-facebook" href="<?php echo e($setting->facebook); ?>"><span> Facebook </span></a></li>
                  <li><a class="icon icon-corporate fa fa-twitter" href="<?php echo e($setting->twitter); ?>"><span> Twitter </span></a></li>
                  <li><a class="icon icon-corporate fa fa-google-plus" href="<?php echo e($setting->twitter); ?>"><span> Google Plus </span></a></li>
                  <li><a class="icon icon-corporate fa fa-instagram" href="<?php echo e($setting->instragram); ?>"><span> Instagram </span></a></li>
                  <li><a class="icon icon-corporate fa fa-linkedin" href="<?php echo e($setting->youtube); ?>"><span> LinkedIn </span></a></li>
                </ul>
              </div>
              <div class="col-lg-3">
                <p class="heading-7">Vilikor Och</p>
                <ul class="list-unstyled">
                  <li><a href="<?php echo e($setting->pt3_option1_link); ?>"><?php echo e($setting->pt3_option1_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt3_option2_link); ?>"><?php echo e($setting->pt3_option2_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt3_option3_link); ?>"><?php echo e($setting->pt3_option3_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt3_option4_link); ?>"><?php echo e($setting->pt3_option4_text); ?></a></li>
                  <li><a href="<?php echo e($setting->pt3_option5_link); ?>"><?php echo e($setting->pt3_option5_text); ?></a></li>
                </ul>
              </div>
            </div>
            <div class="row row-100">
              <div class="col-lg-12 text-center">
                <a class="brand logo" href="<?php echo e(route('home.index')); ?>">
                  <img class="brand-logo-dark" src="<?php echo e(asset('')); ?>frontend/images/logo-icon.png" alt="" width="210" height="41"/>
                  <img class="brand-logo-light" src="<?php echo e($setting->header_logo); ?>" alt="" width="210" height="41"/>
                </a>
                <p class="rights footer-text"><?php echo e($setting->footer_text1); ?> </p>
                
              </div>              
            </div>
          </div>
        </div>
        <div class="footer-classic-aside footer-classic-darken">
          <div class="container">
            
            <div class="layout-justify">
              <div class="rights" style="color: #efefef;">
                <p style="text-align: justify;"><?php echo e($setting->footer_text2); ?> </p>
                <p class="rights" style="color: #efefef;">
                  <span>&nbsp;&copy;&nbsp;</span>
                  <span class="copyright-year"></span>
                  
                  <a class="link-underline" href="#"> STUDIO ALL IN</a>
                  <span>.&nbsp;</span>
                  <span><?php echo e($setting->copy_right); ?>.</span>
                </p>
              </div>
            </div>
            <!-- <div class="layout-justify">
              

              <p class="rights">
                
                
                <span>&nbsp;&copy;&nbsp;</span>
                <span class="copyright-year"></span>
                
                <a class="link-underline" href="#">STUDIO ALL IN</a>
                <span>.&nbsp;</span>
                <span>All right reserved.</span>
              </p>
              <nav class="nav-minimal">
                <ul class="nav-minimal-list">
                  <li class="active"><a href="index.html">Sports</a></li>
                  <li><a href="in-play.html">In-play</a></li>
                  <li><a href="promotions.html">Promotions</a></li>
                  <li><a href="statistics.html">Statistics</a></li>
                  <li><a href="#">Pages</a></li>
                </ul>
              </nav>
            </div> -->
          </div>
        </div>
      </footer>
      <?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/frontend/layout/partial/footer.blade.php ENDPATH**/ ?>