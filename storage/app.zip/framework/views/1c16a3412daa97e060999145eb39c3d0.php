
  <?php $__env->startSection('content'); ?>
  <div class="container-fluid">
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h3 class="text-themecolor">Activices</h3>
            </div>
            <div class="col-md-7 align-self-center">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashbord')); ?>">Home</a></li>
                    <li class="breadcrumb-item">Activices</li>
                    <li class="breadcrumb-item active">Activices Details</li>
                </ol>
            </div>
           
        </div>
        <div class="card">
            <div class="card-body">
                <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <span class="close" data-dismiss="alert"></span>
                    <strong><?php echo e(session('message')); ?></strong>
                </div>
                 <?php endif; ?>
                <h4 class="card-title">Activices Table</h4>
                <h6 class="card-subtitle">All Activices Information</h6>
              
                <div class="table-responsive m-t-40">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>User Name</th>
                                <th>Page</th>
                                <th>Type</th>
                                <th>Create Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Activicess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Activices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(user($Activices->user_id)); ?></td>
                                <td><?php echo e($Activices->page); ?></td>
                                <td ><?php echo e($Activices->type); ?></td>
                                <td><?php echo e(dateFormatconverter($Activices->cdt)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function() {
        $(".js-switch").on( "change",function(){
            var id=$(this).data('id');
         $.ajax({
             url:"ActivicesStatusById/"+id,
             type:"GET",
             success:function(data){
                 
             }
         });
            
        });
    });
  </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\sai\resources\views/Admin/activices/index.blade.php ENDPATH**/ ?>